package entities;

  enum AdminStatus {
	 Applied,
	 Rejected,
	 Pending,
	 Confirmed;
	}

 public class AdmissionStatus{
	 AdminStatus adStatus;
	
	}
	 
	 
		
	


