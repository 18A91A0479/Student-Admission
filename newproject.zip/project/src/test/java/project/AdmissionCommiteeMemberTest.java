package project;

public class AdmissionCommiteeMemberTest {

}
